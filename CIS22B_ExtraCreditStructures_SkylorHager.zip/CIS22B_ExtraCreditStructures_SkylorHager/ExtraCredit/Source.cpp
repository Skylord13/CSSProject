#include <iostream>
#include <string>

using namespace std;

struct compDivision
{
	string name;
	double q1Sales;
	double q2Sales;
	double q3Sales;
	double q4Sales;
	double annualSales;
	double avgSales;

	void setName();
	void setQ1Sales();
	void setQ2Sales();
	void setQ3Sales();
	void setQ4Sales();
	void setAnnualSales();
	void setAvgSales();

	string getName();
	double getQ1Sales();
	double getQ2Sales();
	double getQ3Sales();
	double getQ4Sales();
	double getAnnualSales();
	double getAvgSales();
};

int main()
{
	compDivision d1, d2, d3, d4;

	cout << "What is the first division to be entered?" << endl;
	cin >> d1.name;
	cout << endl << "What is the first quarter sales?" << endl;
	cin >> d1.q1Sales;
	while (d1.q1Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d1.q1Sales;
	}
	cout << endl << "What is the second quarter sales?" << endl;
	cin >> d1.q2Sales;
	while (d1.q2Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d1.q1Sales;
	}
	cout << endl << "What is the third quarter sales?" << endl;
	cin >> d1.q3Sales;
	while (d1.q3Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d1.q3Sales;
	}
	cout << endl << "What is the fourth quarter sales?" << endl;
	cin >> d1.q4Sales;
	while (d1.q4Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d1.q4Sales;
	}
	d1.annualSales = d1.q1Sales + d1.q2Sales + d1.q3Sales + d1.q4Sales;
	d1.avgSales = d1.annualSales / 4;


	cout << endl << endl << "What is the second division to be entered?" << endl;
	cin >> d2.name;
	cout << endl << "What is the first quarter sales?" << endl;
	cin >> d2.q1Sales;
	while (d2.q1Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d2.q1Sales;
	}
	cout << endl << "What is the second quarter sales?" << endl;
	cin >> d2.q2Sales;
	while (d2.q2Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d2.q1Sales;
	}
	cout << endl << "What is the third quarter sales?" << endl;
	cin >> d2.q3Sales;
	while (d2.q3Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d2.q3Sales;
	}
	cout << endl << "What is the fourth quarter sales?" << endl;
	cin >> d2.q4Sales;
	while (d2.q4Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d2.q4Sales;
	}
	d2.annualSales = d2.q1Sales + d2.q2Sales + d2.q3Sales + d2.q4Sales;
	d2.avgSales = d2.annualSales / 4;


	cout << endl << endl << "What is the third division to be entered?" << endl;
	cin >> d3.name;
	cout << endl << "What is the first quarter sales?" << endl;
	cin >> d3.q1Sales;
	while (d3.q1Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d3.q1Sales;
	}
	cout << endl << "What is the second quarter sales?" << endl;
	cin >> d3.q2Sales;
	while (d3.q2Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d3.q1Sales;
	}
	cout << endl << "What is the third quarter sales?" << endl;
	cin >> d3.q3Sales;
	while (d3.q3Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d3.q3Sales;
	}
	cout << endl << "What is the fourth quarter sales?" << endl;
	cin >> d3.q4Sales;
	while (d3.q4Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d3.q4Sales;
	}
	d3.annualSales = d3.q1Sales + d3.q2Sales + d3.q3Sales + d3.q4Sales;
	d3.avgSales = d3.annualSales / 4;


	cout << endl << endl << "What is the fourth division to be entered?" << endl;
	cin >> d4.name;
	cout << endl << "What is the first quarter sales?" << endl;
	cin >> d4.q1Sales;
	while (d4.q1Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d4.q1Sales;
	}
	cout << endl << "What is the second quarter sales?" << endl;
	cin >> d4.q2Sales;
	while (d4.q2Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d4.q1Sales;
	}
	cout << endl << "What is the third quarter sales?" << endl;
	cin >> d4.q3Sales;
	while (d4.q3Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d4.q3Sales;
	}
	cout << endl << "What is the fourth quarter sales?" << endl;
	cin >> d4.q4Sales;
	while (d4.q4Sales < 0)
	{
		cout << endl << "Please enter a number 0 or greater." << endl;
		cin >> d4.q4Sales;
	}
	d4.annualSales = d4.q1Sales + d4.q2Sales + d4.q3Sales + d4.q4Sales;
	d4.avgSales = d4.annualSales / 4;



	cout << endl << "Division: " << d1.name << endl << 
		"First quarter sales: " << d1.q1Sales << endl <<
		"Second quarter sales: " << d1.q2Sales << endl <<
		"Third quarter sales: " << d1.q3Sales << endl <<
		"Fourth quarter sales: " << d1.q4Sales << endl <<
		"Total annual sales: " << d1.annualSales << endl <<
		"Average quarterly sales: " << d1.avgSales << endl << endl;

	cout << endl << "Division: " << d2.name << endl <<
		"First quarter sales: " << d2.q1Sales << endl <<
		"Second quarter sales: " << d2.q2Sales << endl <<
		"Third quarter sales: " << d2.q3Sales << endl <<
		"Fourth quarter sales: " << d2.q4Sales << endl <<
		"Total annual sales: " << d2.annualSales << endl <<
		"Average quarterly sales: " << d2.avgSales << endl << endl;

	cout << endl << "Division: " << d3.name << endl <<
		"First quarter sales: " << d3.q1Sales << endl <<
		"Second quarter sales: " << d3.q2Sales << endl <<
		"Third quarter sales: " << d3.q3Sales << endl <<
		"Fourth quarter sales: " << d3.q4Sales << endl <<
		"Total annual sales: " << d3.annualSales << endl <<
		"Average quarterly sales: " << d3.avgSales << endl << endl;

	cout << endl << "Division: " << d4.name << endl <<
		"First quarter sales: " << d4.q1Sales << endl <<
		"Second quarter sales: " << d4.q2Sales << endl <<
		"Third quarter sales: " << d4.q3Sales << endl <<
		"Fourth quarter sales: " << d4.q4Sales << endl <<
		"Total annual sales: " << d4.annualSales << endl <<
		"Average quarterly sales: " << d4.avgSales << endl << endl <<
		"Press any key to exit. . .";
	system("pause");

}